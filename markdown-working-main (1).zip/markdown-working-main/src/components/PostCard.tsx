
import { Link } from "react-router-dom";
import { cn, formatDate } from "@/lib/utils";
import { ArrowRight } from "lucide-react";

interface PostCardProps {
  title: string;
  excerpt: string;
  date: string;
  slug: string;
  category: string;
  className?: string;
}

const PostCard = ({
  title,
  excerpt,
  date,
  slug,
  category,
  className,
}: PostCardProps) => {
  return (
    <div 
      className={cn(
        "group relative flex flex-col p-6 bg-card border rounded-xl transition-all duration-300 hover:border-primary/30 hover:shadow-sm",
        className
      )}
    >
      <div className="space-y-2">
        <div className="space-y-1.5">
          <span className="inline-block text-xs font-medium text-muted-foreground">
            {formatDate(date)}
          </span>
          <h2 className="font-display text-xl font-semibold tracking-tight leading-tight">
            {title}
          </h2>
        </div>
        <p className="text-muted-foreground line-clamp-3">{excerpt}</p>
      </div>
      <div className="mt-auto pt-4">
        <Link
          to={`/${category}/${slug}`}
          className="inline-flex items-center text-sm font-medium text-primary hover:text-primary/90 transition-colors"
        >
          Read more
          <ArrowRight className="h-3.5 w-3.5 ml-1 transition-transform group-hover:translate-x-0.5" />
        </Link>
      </div>
    </div>
  );
};

export default PostCard;
