
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import Container from "./Container";
import { useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";

interface HeaderProps {
  transparent?: boolean;
}

const Header = ({ transparent }: HeaderProps = {}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const isHomePage = location.pathname === "/";
  const categories = ["blog", "coding", "design", "lifestyle", "technology", "health", "tutorials"];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <Container>
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-6 md:gap-10">
            <Link to="/" className="font-display font-bold text-xl md:text-2xl">
              Minimal Blog
            </Link>
            <NavigationMenu className="hidden md:flex">
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link to="/">
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                      Home
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Categories</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      {categories.map((category) => (
                        <li key={category}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={`/categories/${category}`}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                            >
                              <div className="text-sm font-medium leading-none">
                                {category.charAt(0).toUpperCase() + category.slice(1)}
                              </div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                Browse all {category} articles
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>
          <div className="flex items-center gap-2">
            <form onSubmit={handleSearch} className="flex-1 md:w-auto md:flex-none">
              <div className="hidden sm:flex items-center gap-2">
                <Input
                  type="search"
                  placeholder="Search articles..."
                  className="w-[150px] lg:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit" size="icon" variant="ghost">
                  <Search className="h-5 w-5" />
                  <span className="sr-only">Search</span>
                </Button>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="sm:hidden"
                onClick={() => navigate('/search')}
              >
                <Search className="h-5 w-5" />
                <span className="sr-only">Search</span>
              </Button>
            </form>
          </div>
        </div>
      </Container>
      {/* Hero section on home page */}
      {isHomePage && (
        <div className="border-b bg-muted/40">
          <Container>
            <div className="flex flex-col items-center py-14 text-center">
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold font-display tracking-tight mb-4">
                Minimal Blog
              </h1>
              <p className="max-w-[42rem] text-muted-foreground text-lg mb-6">
                A minimalist blog platform for sharing ideas,
                tutorials, and insights. Simple, clean, and focused on content.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button asChild>
                  <Link to="/categories">Browse Categories</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link to="/search">Search Articles</Link>
                </Button>
              </div>
            </div>
          </Container>
        </div>
      )}
    </header>
  );
};

export default Header;
