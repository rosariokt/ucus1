
import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import { cn } from "@/lib/utils";

interface BackButtonProps {
  className?: string;
}

const BackButton = ({ className }: BackButtonProps) => {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(-1)}
      className={cn(
        "group flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors",
        className
      )}
      aria-label="Go back"
    >
      <ChevronLeft className="h-4 w-4 mr-1 transition-transform group-hover:-translate-x-0.5" />
      Back
    </button>
  );
};

export default BackButton;
