
---
title: Understanding React Hooks
date: 2023-12-10
excerpt: A comprehensive guide to React Hooks and how they can simplify your component logic. Learn about useState, useEffect, and custom hooks.
---

# Understanding React Hooks

React Hooks were introduced in React 16.8 and have revolutionized how we write components.

## useState Hook

The useState hook lets you add state to functional components:

```jsx
import React, { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);
  
  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
  );
}
```

## useEffect Hook

The useEffect hook handles side effects in your component:

```jsx
useEffect(() => {
  document.title = `You clicked ${count} times`;
}, [count]); // Only re-run if count changes
```

Hooks make your code more reusable and easier to test!
