
---
title: Typography Basics Every Designer Should Know
date: 2024-03-08
excerpt: Explore the fundamentals of typography and learn how to select and pair fonts to enhance readability and visual appeal in your designs.
---

# Typography Basics Every Designer Should Know

Typography is much more than just choosing fonts—it's an art form that impacts how your message is received.

## Font Classifications

- Serif: Has small lines at the ends of characters (e.g., Times New Roman)
- Sans-serif: No small lines (e.g., Helvetica)
- Display: Decorative fonts for headlines
- Monospace: Each character takes up equal space

## Typography Principles

1. Hierarchy: Guide the reader's eye through your content
2. Readability: Text should be easy to read at the intended size
3. Contrast: Create visual interest through size and weight differences
4. Consistency: Maintain a coherent system across your design

Good typography often goes unnoticed, but bad typography is immediately apparent.
