import { useState, useEffect } from "react";
import Container from "@/components/Container";
import Header from "@/components/Header";
import PostCard from "@/components/PostCard";
import { extractFrontmatter } from "@/lib/utils";

interface Post {
  title: string;
  date: string;
  excerpt: string;
  slug: string;
  category: string;
}

const Index = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const markdownFiles = import.meta.glob("../content/**/*.md", { eager: true, as: "raw" });
    
    const loadedPosts = Object.entries(markdownFiles).map(([path, content]) => {
      const pathParts = path.split("/");
      const category = pathParts[pathParts.length - 2];
      const filename = pathParts[pathParts.length - 1];
      const slug = filename.replace(".md", "");
      
      const { frontmatter, content: postContent } = extractFrontmatter(content as string);
      
      return {
        title: frontmatter.title || slug.replace(/-/g, " "),
        date: frontmatter.date || new Date().toISOString().split("T")[0],
        excerpt: frontmatter.excerpt || postContent.substring(0, 150) + "...",
        slug,
        category
      };
    });
    
    loadedPosts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    setPosts(loadedPosts);
    setIsLoading(false);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-12 sm:py-16">
        <section className="mb-16">
          <Container size="small">
            <div className="text-center space-y-4 animate-slide-up">
              <h1 className="text-4xl sm:text-5xl font-display font-bold tracking-tight">
                Minimal Blog
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                A beautiful, minimalist blog platform focused on content and readability.
              </p>
            </div>
          </Container>
        </section>

        <Container>
          <h2 className="text-2xl font-display font-semibold mb-6 animate-slide-up">
            Latest Posts
          </h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div 
                  key={i}
                  className="animate-pulse h-64 rounded-xl bg-secondary"
                ></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {posts.map((post, index) => (
                <div 
                  key={`${post.category}-${post.slug}`}
                  className="animate-scale-in"
                  style={{ 
                    animationDelay: `${index * 100}ms`,
                    animationFillMode: "both" 
                  }}
                >
                  <PostCard
                    title={post.title}
                    excerpt={post.excerpt}
                    date={post.date}
                    slug={post.slug}
                    category={post.category}
                  />
                </div>
              ))}
            </div>
          )}
        </Container>
      </main>
      
      <footer className="border-t py-8 mt-16">
        <Container>
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Minimal Blog. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 sm:mt-0">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms
              </a>
            </div>
          </div>
        </Container>
      </footer>
    </div>
  );
};

export default Index;
