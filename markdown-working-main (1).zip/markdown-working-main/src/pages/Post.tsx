
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Container from "@/components/Container";
import Header from "@/components/Header";
import BackButton from "@/components/BackButton";
import { formatDate, extractFrontmatter } from "@/lib/utils";
import { CalendarIcon } from "lucide-react";

const Post = () => {
  const { category, slug } = useParams<{ category: string; slug: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<{
    title: string;
    date: string;
    content: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadPost = async () => {
      try {
        // Load from the category/slug path structure
        const markdownModule = await import(`../content/${category}/${slug}.md`);
        const markdown = markdownModule.default;
        
        // Extract frontmatter
        const { frontmatter, content } = extractFrontmatter(markdown);
        
        setPost({
          title: frontmatter.title || slug?.replace(/-/g, " ") || "Untitled",
          date: frontmatter.date || new Date().toISOString().split("T")[0],
          content,
        });
        setIsLoading(false);
      } catch (err) {
        console.error("Failed to load post:", err);
        setError("The post you're looking for doesn't exist.");
        setIsLoading(false);
      }
    };

    if (category && slug) {
      loadPost();
    } else {
      setError("Invalid post URL.");
      setIsLoading(false);
    }
  }, [slug, category]);

  // For markdown rendering
  const renderMarkdown = (markdown: string) => {
    // This is a simple approach for demo purposes
    // In a real app, you'd use a proper Markdown parser like react-markdown
    
    // For headers
    let html = markdown
      .replace(/^# (.*$)/gm, '<h1>$1</h1>')
      .replace(/^## (.*$)/gm, '<h2>$1</h2>')
      .replace(/^### (.*$)/gm, '<h3>$1</h3>')
      .replace(/^#### (.*$)/gm, '<h4>$1</h4>');
    
    // For paragraphs
    html = html.replace(/^\s*(\n)?(.+)/gm, function(m) {
      return /\<(\/)?(h|ul|ol|li|blockquote|pre|img)/.test(m) ? m : '<p>' + m + '</p>';
    });
    
    // For bold
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // For italic
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    // For code blocks
    html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    
    // For inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // For links
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
    
    // For unordered lists
    html = html.replace(/^\s*-\s*(.*)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>)/g, '<ul>$1</ul>');
    
    // For ordered lists
    html = html.replace(/^\s*(\d+\.\s.*)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>\d+\.\s.*<\/li>)/g, '<ol>$1</ol>');
    
    // For blockquotes
    html = html.replace(/^\>\s*(.*)$/gm, '<blockquote>$1</blockquote>');
    
    return html;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-12">
          <Container size="small">
            <div className="animate-pulse space-y-6">
              <div className="h-8 w-3/4 bg-secondary rounded"></div>
              <div className="h-6 w-1/4 bg-secondary rounded"></div>
              <div className="space-y-3">
                <div className="h-4 bg-secondary rounded"></div>
                <div className="h-4 bg-secondary rounded"></div>
                <div className="h-4 bg-secondary rounded"></div>
                <div className="h-4 w-4/5 bg-secondary rounded"></div>
              </div>
            </div>
          </Container>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-12">
          <Container size="small">
            <div className="text-center space-y-6">
              <h1 className="text-3xl font-display font-bold">Post Not Found</h1>
              <p className="text-muted-foreground">{error}</p>
              <button
                onClick={() => navigate("/")}
                className="inline-flex items-center px-4 py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
              >
                Back to Home
              </button>
            </div>
          </Container>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-12">
        <Container size="small">
          <div className="mb-6 animate-slide-down">
            <BackButton />
          </div>
          <article className="animate-blur-in">
            <header className="mb-8">
              <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight leading-tight">
                {post?.title}
              </h1>
              {post?.date && (
                <div className="flex items-center mt-4 text-muted-foreground">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  <time dateTime={post.date}>{formatDate(post.date)}</time>
                </div>
              )}
            </header>
            {post?.content && (
              <div 
                className="markdown-content prose prose-lg max-w-none"
                dangerouslySetInnerHTML={{ 
                  __html: renderMarkdown(post.content) 
                }}
              />
            )}
          </article>
        </Container>
      </main>

      <footer className="border-t py-8 mt-16">
        <Container>
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Minimal Blog. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 sm:mt-0">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms
              </a>
            </div>
          </div>
        </Container>
      </footer>
    </div>
  );
};

export default Post;
