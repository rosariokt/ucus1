import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import Container from "@/components/Container";
import Header from "@/components/Header";
import PostCard from "@/components/PostCard";
import { extractFrontmatter } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";

interface Post {
  title: string;
  date: string;
  excerpt: string;
  slug: string;
  category: string;
}

const Category = () => {
  const { category } = useParams<{ category: string }>();
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [categories, setCategories] = useState<string[]>([]);

  useEffect(() => {
    const loadPosts = async () => {
      setIsLoading(true);
      try {
        // Dynamically import all markdown files from the category folder
        const modules = import.meta.glob("/src/content/**/*.md", { eager: true, as: "raw" });
        const allPosts: Post[] = [];
        const categorySet = new Set<string>();

        for (const path in modules) {
          const content = modules[path] as string;
          const { frontmatter } = extractFrontmatter(content);
          
          // Extract category from path
          const pathSegments = path.split("/");
          const postCategory = pathSegments[pathSegments.length - 2];
          const filename = pathSegments[pathSegments.length - 1];
          const slug = filename.replace(".md", "");
          
          categorySet.add(postCategory);
          
          allPosts.push({
            title: frontmatter.title || "Untitled",
            date: frontmatter.date || new Date().toISOString().split("T")[0],
            excerpt: frontmatter.excerpt || "",
            slug,
            category: postCategory
          });
        }

        // Filter posts by the current category if provided
        const filteredPosts = category 
          ? allPosts.filter(post => post.category === category)
          : allPosts;
        
        // Sort posts by date (newest first)
        filteredPosts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        
        setPosts(filteredPosts);
        setCategories(Array.from(categorySet));
        setIsLoading(false);
      } catch (error) {
        console.error("Error loading posts:", error);
        setIsLoading(false);
      }
    };

    loadPosts();
  }, [category]);

  // Capitalize the first letter of category
  const formatCategoryName = (cat: string) => {
    return cat.charAt(0).toUpperCase() + cat.slice(1);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-12">
        <Container>
          <Breadcrumb className="mb-6">
            <BreadcrumbList>
              <BreadcrumbItem>
                <Link to="/" className="text-sm font-medium hover:underline">Home</Link>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              {category ? (
                <BreadcrumbItem>
                  <BreadcrumbPage>{formatCategoryName(category)}</BreadcrumbPage>
                </BreadcrumbItem>
              ) : (
                <BreadcrumbItem>
                  <BreadcrumbPage>All Categories</BreadcrumbPage>
                </BreadcrumbItem>
              )}
            </BreadcrumbList>
          </Breadcrumb>

          <div className="mb-10">
            <h1 className="text-4xl font-display font-bold tracking-tight mb-4">
              {category ? `${formatCategoryName(category)} Posts` : "All Posts"}
            </h1>
            <p className="text-muted-foreground text-lg">
              {category 
                ? `Browse our collection of articles about ${category}.` 
                : "Browse all of our articles across different categories."}
            </p>
          </div>

          <Tabs defaultValue={category || "all"} className="mb-8">
            <TabsList className="mb-6">
              <TabsTrigger 
                value="all" 
                asChild
              >
                <Link to="/categories">All</Link>
              </TabsTrigger>
              {categories.map((cat) => (
                <TabsTrigger 
                  key={cat} 
                  value={cat} 
                  asChild
                >
                  <Link to={`/categories/${cat}`}>{formatCategoryName(cat)}</Link>
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="animate-pulse p-6 border rounded-xl">
                  <div className="h-4 bg-secondary rounded w-1/4 mb-4"></div>
                  <div className="h-6 bg-secondary rounded w-3/4 mb-4"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-secondary rounded"></div>
                    <div className="h-4 bg-secondary rounded"></div>
                    <div className="h-4 bg-secondary rounded w-5/6"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : posts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {posts.map((post) => (
                <PostCard
                  key={`${post.category}-${post.slug}`}
                  title={post.title}
                  excerpt={post.excerpt}
                  date={post.date}
                  slug={post.slug}
                  category={post.category}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-2xl font-display font-semibold mb-2">No posts found</h3>
              <p className="text-muted-foreground">
                {category 
                  ? `There are no posts in the ${category} category yet.` 
                  : "There are no posts available."}
              </p>
            </div>
          )}
        </Container>
      </main>

      <footer className="border-t py-8 mt-16">
        <Container>
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Minimal Blog. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 sm:mt-0">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terms
              </a>
            </div>
          </div>
        </Container>
      </footer>
    </div>
  );
};

export default Category;
