
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(dateString: string) {
  const date = new Date(dateString);
  // Format: January 1, 2023
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function slugify(text: string) {
  return text
    .toString()
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-')
    .replace(/^-+/, '')
    .replace(/-+$/, '');
}

// This function helps extract frontmatter from markdown content
export function extractFrontmatter(content: string) {
  const frontmatterRegex = /---\s*([\s\S]*?)\s*---/;
  const match = frontmatterRegex.exec(content);
  
  if (!match) return { frontmatter: {}, content };
  
  const frontmatterString = match[1];
  const remainingContent = content.replace(frontmatterRegex, '').trim();
  const frontmatter: Record<string, string> = {};
  
  // Parse frontmatter
  frontmatterString.split('\n').forEach(line => {
    const [key, ...valueArr] = line.split(':');
    if (key && valueArr.length) {
      frontmatter[key.trim()] = valueArr.join(':').trim();
    }
  });
  
  return { frontmatter, content: remainingContent };
}
